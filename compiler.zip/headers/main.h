#include "nodes.h"

void print_tree(NODE *tree);